// src/cli.ts
// CLI entry point for batch Java → TypeScript conversion
// Features: per-file progress, colored output, HTML report, JSON report, error recovery

import * as fs from 'fs';
import * as path from 'path';
import { transformJavaToTypeScript } from './core/pipeline';
import { buildImportGraph } from './import-graph/graph-builder';
import { emitTypeScript } from './core/emitter';
import type { CompilationUnit } from './types/uast';

export interface TransformResult {
  sourcePath: string;
  outputPath: string;
  status: 'success' | 'partial' | 'failed';
  durationMs: number;
  linesProcessed: number;
  linesOutput: number;
  errors: string[];
  warnings: string[];
  unsupportedNodes: string[];
  output?: string;
}

export interface CliOptions {
  sourceDir: string;
  outputDir: string;
  testMode?: boolean;
  sourceMap?: boolean;
  dryRun?: boolean;
  verbose?: boolean;
  reportFormat?: 'html' | 'json' | 'both';
}

// ANSI color codes
const C = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m',
  bgRed: '\x1b[41m',
  bgGreen: '\x1b[42m',
  bgYellow: '\x1b[43m',
};

function color(text: string, colorCode: string): string {
  return colorCode + text + C.reset;
}

function findJavaFiles(dir: string): string[] {
  const results: string[] = [];
  if (!fs.existsSync(dir)) return results;
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const entry of entries) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results.push(...findJavaFiles(fullPath));
    } else if (entry.name.endsWith('.java')) {
      results.push(fullPath);
    }
  }
  return results;
}

function getOutputPath(javaPath: string, sourceDir: string, outputDir: string): string {
  const relative = path.relative(sourceDir, javaPath);
  const tsPath = relative.replace(/\.java$/, '.ts');
  return path.join(outputDir, tsPath);
}

function ensureDir(dir: string) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

function countLines(text: string): number {
  return text.split('\n').length;
}

function extractUnsupportedNodes(output: string): string[] {
  const nodes: string[] = [];
  const regex = /\/\* TODO: unhandled node kind: (\w+) \*\//g;
  let match;
  while ((match = regex.exec(output)) !== null) {
    if (!nodes.includes(match[1])) nodes.push(match[1]);
  }
  return nodes;
}

function printProgress(current: number, total: number, result: TransformResult) {
  const pct = Math.round((current / total) * 100);
  const barWidth = 30;
  const filled = Math.round((current / total) * barWidth);
  const bar = '█'.repeat(filled) + '░'.repeat(barWidth - filled);

  const statusIcon = result.status === 'success' ? color('✓', C.green) 
    : result.status === 'partial' ? color('⚠', C.yellow) 
    : color('✗', C.red);

  const statusText = result.status === 'success' ? color('MIGRATED', C.green)
    : result.status === 'partial' ? color('PARTIAL', C.yellow)
    : color('FAILED', C.red);

  const relPath = path.basename(result.sourcePath);
  const timing = color(`${result.durationMs}ms`, C.dim);

  console.log(`\n${color(`[${current}/${total}]`, C.cyan)} ${bar} ${color(`${pct}%`, C.cyan)}`);
  console.log(`  ${statusIcon} ${color(relPath, C.bright)} ${statusText} ${timing}`);

  if (result.warnings.length > 0) {
    result.warnings.forEach(w => console.log(`    ${color('⚠', C.yellow)} ${w}`));
  }
  if (result.errors.length > 0) {
    result.errors.forEach(e => console.log(`    ${color('✗', C.red)} ${e}`));
  }
  if (result.unsupportedNodes.length > 0) {
    console.log(`    ${color('ℹ', C.blue)} Unsupported nodes: ${result.unsupportedNodes.join(', ')}`);
  }
}

export function runBatchConversion(opts: CliOptions): TransformResult[] {
  const javaFiles = findJavaFiles(opts.sourceDir);
  const results: TransformResult[] = [];

  console.log(color('\n╔══════════════════════════════════════════════════════════════╗', C.cyan));
  console.log(color('║     Java Selenium → Playwright TypeScript Migrator v0.8.0    ║', C.cyan));
  console.log(color('╚══════════════════════════════════════════════════════════════╝\n', C.cyan));

  console.log(color(`Source:  ${opts.sourceDir}`, C.dim));
  console.log(color(`Output:  ${opts.outputDir}`, C.dim));
  console.log(color(`Mode:    ${opts.testMode ? 'Test' : 'Page Object'}`, C.dim));
  console.log(color(`Files:   ${javaFiles.length} Java files found\n`, C.dim));

  if (javaFiles.length === 0) {
    console.log(color('No Java files found in source directory.', C.yellow));
    return results;
  }

  // Build import graph for dependency analysis
  const fileMap = new Map<string, string>();
  for (const file of javaFiles) {
    fileMap.set(file, fs.readFileSync(file, 'utf-8'));
  }
  const graph = buildImportGraph(fileMap);

  console.log(color(`Import graph: ${graph.nodes.size} nodes, ${graph.edges.length} edges\n`, C.dim));

  const startTime = Date.now();

  for (let i = 0; i < javaFiles.length; i++) {
    const javaPath = javaFiles[i];
    const result = processFile(javaPath, opts, i + 1, javaFiles.length);
    results.push(result);
    printProgress(i + 1, javaFiles.length, result);
  }

  const totalTime = Date.now() - startTime;

  // Print summary
  const successCount = results.filter(r => r.status === 'success').length;
  const partialCount = results.filter(r => r.status === 'partial').length;
  const failedCount = results.filter(r => r.status === 'failed').length;

  console.log(color('\n═══════════════════════════════════════════════════════════════', C.cyan));
  console.log(color('                      MIGRATION SUMMARY', C.bright));
  console.log(color('═══════════════════════════════════════════════════════════════', C.cyan));
  console.log(`  ${color('✓', C.green)} Migrated:  ${color(String(successCount), C.green)} files`);
  console.log(`  ${color('⚠', C.yellow)} Partial:   ${color(String(partialCount), C.yellow)} files`);
  console.log(`  ${color('✗', C.red)} Failed:    ${color(String(failedCount), C.red)} files`);
  console.log(`  ${color('⏱', C.cyan)} Total time: ${color(`${totalTime}ms`, C.cyan)}`);
  console.log(color('═══════════════════════════════════════════════════════════════\n', C.cyan));

  // Generate reports
  if (opts.reportFormat === 'json' || opts.reportFormat === 'both') {
    generateJsonReport(results, opts);
  }
  if (opts.reportFormat === 'html' || opts.reportFormat === 'both') {
    generateHtmlReport(results, opts, graph, totalTime);
  }

  return results;
}

function processFile(javaPath: string, opts: CliOptions, index: number, total: number): TransformResult {
  const outputPath = getOutputPath(javaPath, opts.sourceDir, opts.outputDir);
  const result: TransformResult = {
    sourcePath: javaPath,
    outputPath,
    status: 'failed',
    durationMs: 0,
    linesProcessed: 0,
    linesOutput: 0,
    errors: [],
    warnings: [],
    unsupportedNodes: [],
  };

  const startTime = Date.now();

  try {
    const javaSource = fs.readFileSync(javaPath, 'utf-8');
    result.linesProcessed = countLines(javaSource);

    const tsOutput = transformJavaToTypeScript(javaSource, {
      testMode: opts.testMode,
      sourceMap: opts.sourceMap,
    });

    result.linesOutput = countLines(tsOutput);
    result.durationMs = Date.now() - startTime;
    result.output = tsOutput;
    result.unsupportedNodes = extractUnsupportedNodes(tsOutput);

    // Determine status
    if (result.unsupportedNodes.length > 0) {
      result.status = 'partial';
      result.warnings.push(`${result.unsupportedNodes.length} unsupported AST nodes`);
    } else {
      result.status = 'success';
    }

    // Write output
    if (!opts.dryRun) {
      ensureDir(path.dirname(outputPath));
      fs.writeFileSync(outputPath, tsOutput, 'utf-8');
    }

  } catch (err: any) {
    result.durationMs = Date.now() - startTime;
    result.errors.push(err.message);
    result.status = 'failed';

    // Write error file
    if (!opts.dryRun) {
      ensureDir(path.dirname(outputPath));
      const errorContent = `// MIGRATION FAILED: ${err.message}\n// File: ${javaPath}\n// Timestamp: ${new Date().toISOString()}\n\n/*\n${fs.readFileSync(javaPath, 'utf-8')}\n*/`;
      fs.writeFileSync(outputPath + '.error', errorContent, 'utf-8');
    }
  }

  return result;
}

function generateJsonReport(results: TransformResult[], opts: CliOptions) {
  const reportPath = path.join(opts.outputDir, 'migration-report.json');
  const report = {
    version: '0.8.0',
    timestamp: new Date().toISOString(),
    summary: {
      total: results.length,
      success: results.filter(r => r.status === 'success').length,
      partial: results.filter(r => r.status === 'partial').length,
      failed: results.filter(r => r.status === 'failed').length,
      successRate: results.length > 0 
        ? Math.round((results.filter(r => r.status === 'success').length / results.length) * 100) 
        : 0,
    },
    files: results.map(r => ({
      sourcePath: r.sourcePath,
      outputPath: r.outputPath,
      status: r.status,
      durationMs: r.durationMs,
      linesProcessed: r.linesProcessed,
      linesOutput: r.linesOutput,
      errors: r.errors,
      warnings: r.warnings,
      unsupportedNodes: r.unsupportedNodes,
    })),
  };

  if (!opts.dryRun) {
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2), 'utf-8');
    console.log(color(`📄 JSON report: ${reportPath}`, C.dim));
  }
}

function generateHtmlReport(results: TransformResult[], opts: CliOptions, graph: any, totalTime: number) {
  const reportPath = path.join(opts.outputDir, 'migration-report.html');

  const successCount = results.filter(r => r.status === 'success').length;
  const partialCount = results.filter(r => r.status === 'partial').length;
  const failedCount = results.filter(r => r.status === 'failed').length;
  const totalLines = results.reduce((sum, r) => sum + r.linesProcessed, 0);
  const totalOutputLines = results.reduce((sum, r) => sum + r.linesOutput, 0);

  // Collect all unsupported nodes across files
  const allUnsupported = new Map<string, string[]>();
  results.forEach(r => {
    r.unsupportedNodes.forEach(node => {
      if (!allUnsupported.has(node)) allUnsupported.set(node, []);
      allUnsupported.get(node)!.push(path.basename(r.sourcePath));
    });
  });

  // Collect all errors
  const allErrors = results.filter(r => r.errors.length > 0);

  // Collect unresolved imports (files referenced but not in source)
  const sourceFiles = new Set(results.map(r => r.sourcePath));
  const unresolvedImports: string[] = [];
  graph.edges.forEach((edge: any) => {
    if (!sourceFiles.has(edge.to) && !unresolvedImports.includes(edge.to)) {
      unresolvedImports.push(edge.to);
    }
  });

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Migration Report — Selenium → Playwright</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,sans-serif;background:#0f172a;color:#e2e8f0;line-height:1.6;padding:20px}
.container{max-width:1400px;margin:0 auto}
header{text-align:center;padding:40px 0;border-bottom:1px solid #334155;margin-bottom:30px}
header h1{font-size:2.5rem;font-weight:700;background:linear-gradient(90deg,#38bdf8,#818cf8);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:10px}
header .subtitle{color:#94a3b8;font-size:1.1rem}
header .timestamp{color:#64748b;font-size:0.9rem;margin-top:8px}

.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:20px;margin-bottom:40px}
.card{background:#1e293b;border-radius:12px;padding:24px;text-align:center;border:1px solid #334155;transition:transform .2s}
.card:hover{transform:translateY(-4px)}
.card .icon{font-size:2rem;margin-bottom:12px}
.card .number{font-size:2.5rem;font-weight:700;margin-bottom:4px}
.card .label{color:#94a3b8;font-size:0.95rem}
.card.success .number{color:#4ade80}
.card.partial .number{color:#fbbf24}
.card.failed .number{color:#f87171}
.card.info .number{color:#38bdf8}

.section{background:#1e293b;border-radius:12px;padding:24px;margin-bottom:24px;border:1px solid #334155}
.section h2{font-size:1.3rem;margin-bottom:16px;display:flex;align-items:center;gap:10px}
.section h2 .count{background:#334155;padding:2px 10px;border-radius:20px;font-size:0.85rem}

.filter-bar{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}
.filter-btn{background:#334155;border:none;color:#e2e8f0;padding:6px 16px;border-radius:6px;cursor:pointer;font-size:0.9rem;transition:all .2s}
.filter-btn:hover{background:#475569}
.filter-btn.active{background:#38bdf8;color:#0f172a}

table{width:100%;border-collapse:collapse;font-size:0.9rem}
th{text-align:left;padding:12px 16px;background:#0f172a;color:#94a3b8;font-weight:600;text-transform:uppercase;font-size:0.8rem;letter-spacing:0.05em}
td{padding:12px 16px;border-bottom:1px solid #334155}
tr:hover{background:#252f47}
.status-badge{display:inline-block;padding:4px 12px;border-radius:20px;font-size:0.8rem;font-weight:600}
.status-success{background:rgba(74,222,128,.15);color:#4ade80}
.status-partial{background:rgba(251,191,36,.15);color:#fbbf24}
.status-failed{background:rgba(248,113,113,.15);color:#f87171}
.file-path{font-family:'SF Mono',Monaco,monospace;font-size:0.85rem;color:#cbd5e1}
.file-path .dir{color:#64748b}
.timing{color:#94a3b8;font-size:0.85rem}
.issues{font-size:0.85rem;color:#fbbf24}
.errors{font-size:0.85rem;color:#f87171}

.pie-chart{display:flex;align-items:center;gap:40px;flex-wrap:wrap}
.pie-container{position:relative;width:200px;height:200px}
.pie{position:relative;width:200px;height:200px;border-radius:50%;background:conic-gradient(
  #4ade80 0deg ${successCount/results.length*360}deg,
  #fbbf24 ${successCount/results.length*360}deg ${(successCount+partialCount)/results.length*360}deg,
  #f87171 ${(successCount+partialCount)/results.length*360}deg 360deg
)}
.pie-center{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:140px;height:140px;background:#1e293b;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.5rem;font-weight:700}
.legend{display:flex;flex-direction:column;gap:12px}
.legend-item{display:flex;align-items:center;gap:10px}
.legend-color{width:16px;height:16px;border-radius:4px}
.legend-text{font-size:0.95rem}
.legend-count{color:#94a3b8;font-size:0.85rem}

.issue-list{list-style:none}
.issue-list li{padding:10px 0;border-bottom:1px solid #334155;display:flex;justify-content:space-between;align-items:center}
.issue-list li:last-child{border-bottom:none}
.issue-name{font-family:'SF Mono',Monaco,monospace;color:#fbbf24}
.issue-files{color:#94a3b8;font-size:0.85rem}

.recommendation{background:#0f172a;border-left:4px solid #38bdf8;padding:16px;border-radius:0 8px 8px 0;margin-bottom:12px}
.recommendation h4{color:#38bdf8;margin-bottom:6px}
.recommendation p{color:#94a3b8;font-size:0.9rem}

.footer{text-align:center;padding:40px 0;color:#64748b;font-size:0.9rem;border-top:1px solid #334155;margin-top:40px}

@media(max-width:768px){.cards{grid-template-columns:1fr}.pie-chart{justify-content:center}}
</style>
</head>
<body>
<div class="container">

<header>
  <h1>🎭 Migration Report</h1>
  <p class="subtitle">Java Selenium → Playwright TypeScript</p>
  <p class="timestamp">Generated: ${new Date().toLocaleString()}</p>
</header>

<div class="cards">
  <div class="card info">
    <div class="icon">📁</div>
    <div class="number">${results.length}</div>
    <div class="label">Total Files</div>
  </div>
  <div class="card success">
    <div class="icon">✅</div>
    <div class="number">${successCount}</div>
    <div class="label">Fully Migrated</div>
  </div>
  <div class="card partial">
    <div class="icon">⚠️</div>
    <div class="number">${partialCount}</div>
    <div class="label">Partial Migration</div>
  </div>
  <div class="card failed">
    <div class="icon">❌</div>
    <div class="number">${failedCount}</div>
    <div class="label">Failed</div>
  </div>
  <div class="card info">
    <div class="icon">📊</div>
    <div class="number">${results.length > 0 ? Math.round((successCount / results.length) * 100) : 0}%</div>
    <div class="label">Success Rate</div>
  </div>
  <div class="card info">
    <div class="icon">⏱️</div>
    <div class="number">${(totalTime / 1000).toFixed(1)}s</div>
    <div class="label">Total Time</div>
  </div>
</div>

<div class="section">
  <h2>📈 Success Breakdown</h2>
  <div class="pie-chart">
    <div class="pie-container">
      <div class="pie">
        <div class="pie-center">${results.length > 0 ? Math.round((successCount / results.length) * 100) : 0}%</div>
      </div>
    </div>
    <div class="legend">
      <div class="legend-item">
        <div class="legend-color" style="background:#4ade80"></div>
        <span class="legend-text">Fully Migrated</span>
        <span class="legend-count">${successCount} files</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background:#fbbf24"></div>
        <span class="legend-text">Partial Migration</span>
        <span class="legend-count">${partialCount} files</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background:#f87171"></div>
        <span class="legend-text">Failed</span>
        <span class="legend-count">${failedCount} files</span>
      </div>
      <div class="legend-item">
        <div class="legend-color" style="background:#38bdf8"></div>
        <span class="legend-text">Lines Processed</span>
        <span class="legend-count">${totalLines.toLocaleString()} → ${totalOutputLines.toLocaleString()}</span>
      </div>
    </div>
  </div>
</div>

<div class="section">
  <h2>📁 File-by-File Results <span class="count">${results.length}</span></h2>
  <div class="filter-bar">
    <button class="filter-btn active" onclick="filterTable('all')">All</button>
    <button class="filter-btn" onclick="filterTable('success')">Success</button>
    <button class="filter-btn" onclick="filterTable('partial')">Partial</button>
    <button class="filter-btn" onclick="filterTable('failed')">Failed</button>
  </div>
  <table id="fileTable">
    <thead>
      <tr>
        <th>Status</th>
        <th>File</th>
        <th>Lines</th>
        <th>Time</th>
        <th>Issues</th>
      </tr>
    </thead>
    <tbody>
      ${results.map(r => {
        const relPath = path.relative(opts.sourceDir, r.sourcePath);
        const dir = path.dirname(relPath);
        const file = path.basename(relPath);
        const statusClass = r.status === 'success' ? 'status-success' : r.status === 'partial' ? 'status-partial' : 'status-failed';
        const statusText = r.status === 'success' ? 'Migrated' : r.status === 'partial' ? 'Partial' : 'Failed';
        const issues = [...r.warnings, ...r.errors].join('; ') || (r.unsupportedNodes.length > 0 ? `${r.unsupportedNodes.length} unsupported nodes` : '-');
        return `<tr data-status="${r.status}">
          <td><span class="status-badge ${statusClass}">${statusText}</span></td>
          <td class="file-path"><span class="dir">${dir}/</span>${file}</td>
          <td class="timing">${r.linesProcessed} → ${r.linesOutput}</td>
          <td class="timing">${r.durationMs}ms</td>
          <td class="${r.status === 'failed' ? 'errors' : 'issues'}">${issues}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>
</div>

${allUnsupported.size > 0 ? `
<div class="section">
  <h2>🔧 Unsupported Node Types <span class="count">${allUnsupported.size}</span></h2>
  <ul class="issue-list">
    ${Array.from(allUnsupported.entries()).map(([node, files]) => `
      <li>
        <span class="issue-name">${node}</span>
        <span class="issue-files">${files.length} file${files.length > 1 ? 's' : ''}</span>
      </li>
    `).join('')}
  </ul>
</div>
` : ''}

${allErrors.length > 0 ? `
<div class="section">
  <h2>❌ Errors <span class="count">${allErrors.length}</span></h2>
  <ul class="issue-list">
    ${allErrors.map(r => `
      <li>
        <span class="issue-name">${path.basename(r.sourcePath)}</span>
        <span class="issue-files">${r.errors.join('; ')}</span>
      </li>
    `).join('')}
  </ul>
</div>
` : ''}

${unresolvedImports.length > 0 ? `
<div class="section">
  <h2>🔗 Unresolved Dependencies <span class="count">${unresolvedImports.length}</span></h2>
  <ul class="issue-list">
    ${unresolvedImports.map(imp => `
      <li>
        <span class="issue-name">${imp}</span>
        <span class="issue-files">Imported but not found in source</span>
      </li>
    `).join('')}
  </ul>
</div>
` : ''}

<div class="section">
  <h2>💡 Recommendations</h2>
  ${allUnsupported.size > 0 ? `
  <div class="recommendation">
    <h4>Add Missing Rules</h4>
    <p>${Array.from(allUnsupported.keys()).join(', ')} — Add transformation rules in <code>src/rules/selenium/index.ts</code> or <code>src/rules/custom/index.ts</code></p>
  </div>
  ` : ''}
  ${unresolvedImports.length > 0 ? `
  <div class="recommendation">
    <h4>Resolve Missing Files</h4>
    <p>${unresolvedImports.length} imports reference files not found in the source directory. Ensure all project files are included or add stubs.</p>
  </div>
  ` : ''}
  ${failedCount > 0 ? `
  <div class="recommendation">
    <h4>Fix Parser Errors</h4>
    <p>${failedCount} files failed to parse. Check <code>.error</code> files for details. Common fixes: handle generics, annotations, or nested classes.</p>
  </div>
  ` : ''}
  <div class="recommendation">
    <h4>Review Partial Migrations</h4>
    <p>${partialCount} files have unsupported nodes but generated output. Search for <code>/* TODO */</code> comments in output files and manually fix.</p>
  </div>
</div>

<footer class="footer">
  <p>Generated by Pure AST Transformer v0.8.0</p>
  <p>Next steps: Review partial migrations → Add custom rules → Run tests</p>
</footer>

</div>

<script>
function filterTable(status) {
  const rows = document.querySelectorAll('#fileTable tbody tr');
  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');

  rows.forEach(row => {
    if (status === 'all' || row.dataset.status === status) {
      row.style.display = '';
    } else {
      row.style.display = 'none';
    }
  });
}
</script>

</body>
</html>`;

  if (!opts.dryRun) {
    fs.writeFileSync(reportPath, html, 'utf-8');
    console.log(color(`🌐 HTML report: ${reportPath}`, C.dim));
  }
}

// CLI entry
if (require.main === module) {
  const args = process.argv.slice(2);
  const sourceDir = args[0] || './java-src';
  const outputDir = args[1] || './playwright-dest';

  const opts: CliOptions = {
    sourceDir,
    outputDir,
    testMode: args.includes('--test-mode'),
    sourceMap: args.includes('--source-map'),
    dryRun: args.includes('--dry-run'),
    verbose: args.includes('--verbose') || args.includes('-v'),
    reportFormat: args.includes('--json-only') ? 'json' : (args.includes('--html-only') ? 'html' : 'both'),
  };

  runBatchConversion(opts);
}
